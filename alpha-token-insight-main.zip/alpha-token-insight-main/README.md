
# Solana Token Intelligence

## Project Overview

A web application for tracking and analyzing Solana tokens in real-time.

## Technologies Used

- Vite
- TypeScript
- React
- Shadcn UI
- Tailwind CSS

## Local Development Setup

```sh
# Clone the repository
git clone <YOUR_REPOSITORY_URL>

# Navigate to the project directory
cd solana-token-intelligence

# Install dependencies
npm install

# Start the development server
npm run dev
```

## Deployment

Follow your preferred deployment method for Vite React applications.
