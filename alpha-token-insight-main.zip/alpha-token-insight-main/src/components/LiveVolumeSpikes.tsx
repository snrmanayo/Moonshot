
import React, { useState } from "react";
import { ArrowLeft } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import TokenRiskBadge from "./TokenRiskBadge";
import TokenAnalyzer from "./TokenAnalyzer";

interface VolumeSpikeData {
  id: string;
  symbol: string;
  name: string;
  timeAgo: string;
  newBuyers: number;
  dex: string;
  walletPreview: string;
  spikePercentage: string;
  riskScore: number;
}

const volumeSpikes: VolumeSpikeData[] = [
  {
    id: "bonk1",
    symbol: "BONKI",
    name: "BONK Instant",
    timeAgo: "2m ago",
    newBuyers: 124,
    dex: "Jupiter",
    walletPreview: "Bonk1...1111",
    spikePercentage: "+85% Vol",
    riskScore: 65
  },
  {
    id: "sol1",
    symbol: "SPEPE",
    name: "SolPepe",
    timeAgo: "6m ago",
    newBuyers: 32,
    dex: "Raydium",
    walletPreview: "Pepe1...1111",
    spikePercentage: "+220% Vol",
    riskScore: 45
  },
  {
    id: "moon1",
    symbol: "SMOON",
    name: "Moon Finance",
    timeAgo: "8m ago",
    newBuyers: 56,
    dex: "Orca",
    walletPreview: "Moon1...1111",
    spikePercentage: "+76% Vol",
    riskScore: 78
  }
];

const LiveVolumeSpikes = () => {
  const [selectedSpike, setSelectedSpike] = useState<VolumeSpikeData | null>(null);

  return (
    <Card className="bg-moonshot-card-bg border-none">
      <CardHeader className="pb-2">
        <div className="flex items-center">
          <div className="h-2 w-2 rounded-full bg-red-500 animate-pulse mr-2"></div>
          <CardTitle className="text-xl font-semibold text-white">Live Volume Spikes</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        {selectedSpike ? (
          <div>
            <Button 
              variant="ghost" 
              className="mb-4 text-white hover:text-white/80"
              onClick={() => setSelectedSpike(null)}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Spikes
            </Button>
            <TokenAnalyzer selectedToken={selectedSpike} />
          </div>
        ) : (
          <div className="space-y-4">
            {volumeSpikes.map(spike => (
              <VolumeSpikeItem 
                key={spike.id} 
                spike={spike} 
                onClick={() => setSelectedSpike(spike)}
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

interface VolumeSpikeItemProps {
  spike: VolumeSpikeData;
  onClick: () => void;
}

const VolumeSpikeItem = ({ spike, onClick }: VolumeSpikeItemProps) => {
  return (
    <div 
      className="p-3 bg-moonshot-dark-bg/50 rounded-lg hover:bg-moonshot-dark-bg transition-colors cursor-pointer"
      onClick={onClick}
    >
      <div className="flex items-center justify-between mb-2">
        <div>
          <div className="flex items-center">
            <h3 className="font-semibold text-white">{spike.name}</h3>
            <span className="text-xs text-white ml-2">{spike.symbol}</span>
            <span className="ml-2 px-2 py-0.5 bg-purple-600/20 text-purple-400 rounded-full text-xs font-medium">
              {spike.spikePercentage}
            </span>
          </div>
          <div className="flex items-center gap-3 mt-1">
            <span className="text-xs text-white">{spike.timeAgo}</span>
            <span className="text-xs text-white">{spike.newBuyers} new buyers</span>
            <span className="text-xs text-white flex items-center">
              via {spike.dex}
            </span>
          </div>
        </div>
        <TokenRiskBadge score={spike.riskScore} />
      </div>
      <div className="px-2 py-1 bg-black/20 rounded text-xs text-white font-mono">
        {spike.walletPreview}
      </div>
    </div>
  );
};

export default LiveVolumeSpikes;
