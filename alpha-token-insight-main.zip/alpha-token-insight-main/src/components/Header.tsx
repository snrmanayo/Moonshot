
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";

const Header = () => {
  return (
    <header className="py-4 px-6 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className="h-10 w-10 rounded-full bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center">
          <div className="h-8 w-8 rounded-full bg-moonshot-dark-bg flex items-center justify-center">
            <div className="h-6 w-6 rounded-full bg-gradient-to-br from-purple-500 to-blue-600"></div>
          </div>
        </div>
        <span className="text-xl font-bold text-moonshot-purple">MOONSHOT</span>
      </div>
      
      <div className="relative max-w-xl w-full">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input 
          placeholder="Search by token address or name..." 
          className="pl-10 bg-moonshot-card-bg border-moonshot-card-bg focus:border-moonshot-purple"
        />
      </div>
    </header>
  );
};

export default Header;
