
interface TokenRiskBadgeProps {
  score: number;
}

const TokenRiskBadge = ({ score }: TokenRiskBadgeProps) => {
  let badgeClass = "";
  let riskText = "";
  
  if (score < 50) {
    badgeClass = "risk-badge-high";
    riskText = "High Risk";
  } else if (score < 75) {
    badgeClass = "risk-badge-caution";
    riskText = "Caution";
  } else {
    badgeClass = "risk-badge-safe";
    riskText = "Safe";
  }
  
  return (
    <div className="flex flex-col items-center">
      <div className={`text-lg font-bold rounded-full h-10 w-10 flex items-center justify-center ${badgeClass}`}>
        {score}
      </div>
      <span className="text-xs mt-1 text-white">{riskText}</span>
    </div>
  );
};

export default TokenRiskBadge;
