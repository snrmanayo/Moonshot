
import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import TokenRiskBadge from "./TokenRiskBadge";
import TokenAnalyzer from "./TokenAnalyzer";

interface TokenData {
  id: string;
  symbol: string;
  name: string;
  price: string;
  priceChange: string;
  volumeUSD: string;
  volumeChange: string;
  riskScore: number;
  tags: string[];
}

const trendingTokens: TokenData[] = [
  {
    id: "sd",
    symbol: "SDEGEN",
    name: "Solana Degen",
    price: "$0.00023",
    priceChange: "+65.3%",
    volumeUSD: "$342,985",
    volumeChange: "+124.5%",
    riskScore: 68,
    tags: ["New", "Volume Spike", "Many New Buyers"]
  },
  {
    id: "be",
    symbol: "BEAM",
    name: "Moonbeam",
    price: "$0.00156",
    priceChange: "+12.8%",
    volumeUSD: "$895,432",
    volumeChange: "+45.7%",
    riskScore: 82,
    tags: ["Strong Holders", "Creator Verified"]
  },
  {
    id: "rk",
    symbol: "RKFL",
    name: "RocketFuel",
    price: "$0.00007",
    priceChange: "-243.1%",
    volumeUSD: "$125,784",
    volumeChange: "+310.2%",
    riskScore: 35,
    tags: ["Whale Accumulation", "Risk: Creator History"]
  },
  {
    id: "fr",
    symbol: "FRENS",
    name: "Sol Frens",
    price: "$0.00089",
    priceChange: "-23.5%",
    volumeUSD: "$564,231",
    volumeChange: "-12.6%",
    riskScore: 72,
    tags: ["Popular", "LP Locked"]
  },
];

const TrendingTokens = () => {
  const [selectedToken, setSelectedToken] = useState<TokenData | null>(null);

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-semibold text-white">Trending Tokens</h2>
        <span className="text-sm text-white">Past 24 hours</span>
      </div>
      
      {selectedToken ? (
        <div>
          <Button 
            variant="ghost" 
            className="mb-4 text-white hover:text-white/80"
            onClick={() => setSelectedToken(null)}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Trending
          </Button>
          <TokenAnalyzer selectedToken={selectedToken} />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {trendingTokens.map(token => (
            <TrendingTokenCard 
              key={token.id} 
              token={token} 
              onClick={() => setSelectedToken(token)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

interface TrendingTokenCardProps {
  token: TokenData;
  onClick: () => void;
}

const TrendingTokenCard = ({ token, onClick }: TrendingTokenCardProps) => {
  const isPriceChangePositive = !token.priceChange.includes("-");
  const isVolumeChangePositive = !token.volumeChange.includes("-");
  
  return (
    <Card 
      className="bg-moonshot-card-bg border-none overflow-hidden cursor-pointer hover:bg-moonshot-dark-bg/80 transition-colors"
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <div className="h-10 w-10 rounded-full bg-moonshot-dark-bg flex items-center justify-center mr-3">
              <span className="text-sm font-semibold text-white">{token.id.toUpperCase()}</span>
            </div>
            <div>
              <div className="flex items-center">
                <h3 className="font-semibold text-white">{token.name}</h3>
                <span className="text-xs text-white ml-2">{token.symbol}</span>
              </div>
              <div className="flex items-center text-white">
                <p>{token.price}</p>
                <span className={isPriceChangePositive ? "text-xs stat-change-positive ml-1" : "text-xs stat-change-negative ml-1"}>
                  {token.priceChange}
                </span>
              </div>
            </div>
          </div>
          <TokenRiskBadge score={token.riskScore} />
        </div>
        
        <div className="flex justify-between mb-4 text-white">
          <div>
            <p className="text-xs opacity-70">24h Volume</p>
            <div className="flex items-center">
              <p>{token.volumeUSD}</p>
              <span className={isVolumeChangePositive ? "text-xs stat-change-positive ml-1" : "text-xs stat-change-negative ml-1"}>
                {token.volumeChange}
              </span>
            </div>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2">
          {token.tags.map((tag, index) => (
            <Badge 
              key={index} 
              variant="secondary" 
              className="bg-moonshot-dark-bg text-white text-xs hover:bg-moonshot-dark-bg/80"
            >
              {tag}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default TrendingTokens;
