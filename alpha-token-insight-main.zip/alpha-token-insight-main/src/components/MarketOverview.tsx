
import { BarChart3, Database, LineChart } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const MarketOverview = () => {
  return (
    <div className="mb-6">
      <h2 className="text-2xl font-semibold text-purple-400 mb-4">Market Overview</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <MarketCard 
          icon={<Database className="h-6 w-6 text-purple-500" />}
          title="Tokens Tracked"
          value="24,583"
          change="+346"
          isPositive={true}
        />
        <MarketCard 
          icon={<BarChart3 className="h-6 w-6 text-purple-500" />}
          title="Volume Spikes (24h)"
          value="29"
          change="+12%"
          isPositive={true}
        />
        <MarketCard 
          icon={<LineChart className="h-6 w-6 text-purple-500" />}
          title="Total Solana TVL"
          value="$2.84B"
          change="+3.6%"
          isPositive={true}
        />
      </div>
    </div>
  );
};

interface MarketCardProps {
  icon: React.ReactNode;
  title: string;
  value: string;
  change: string;
  isPositive: boolean;
}

const MarketCard = ({ icon, title, value, change, isPositive }: MarketCardProps) => {
  return (
    <Card className="bg-moonshot-card-bg border-none">
      <CardContent className="p-4 flex items-start">
        <div className="p-3 bg-moonshot-dark-bg rounded-lg mr-3">
          {icon}
        </div>
        <div>
          <p className="text-sm text-moonshot-text-muted">{title}</p>
          <p className="text-2xl font-bold">{value}</p>
          <p className={isPositive ? "stat-change-positive text-sm" : "stat-change-negative text-sm"}>
            {change}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default MarketOverview;
