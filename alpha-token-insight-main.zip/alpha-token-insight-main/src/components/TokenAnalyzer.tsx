
import { Search } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useState } from "react";

interface TokenAnalysis {
  id: string;
  symbol: string;
  name: string;
  buyerBehavior: string;
  holderDistribution: string;
  creatorHistory: string;
  contractSafety: string;
}

const TokenAnalyzer = ({ selectedToken = null }: { selectedToken?: any }) => {
  const [tokenAddress, setTokenAddress] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tokenAddress) return;
    
    setIsAnalyzing(true);
    // In a real implementation, this would call an API
    setTimeout(() => {
      setIsAnalyzing(false);
    }, 2000);
  };

  // Mock analysis for demonstration
  const mockAnalysis = selectedToken ? {
    id: selectedToken.id,
    symbol: selectedToken.symbol,
    name: selectedToken.name,
    buyerBehavior: "Multiple wallet clusters detected. High PnL correlation with known trading groups.",
    holderDistribution: "Top 10 wallets hold 45% of supply. Moderate concentration risk.",
    creatorHistory: "Creator wallet launched 3 previous tokens. No rug history detected.",
    contractSafety: "Standard token contract. No mint authority. LP tokens locked.",
  } : null;
  
  return (
    <Card className="bg-moonshot-card-bg border-none">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-white">Token Behavior Analyzer</CardTitle>
      </CardHeader>
      <CardContent>
        {!selectedToken && (
          <form onSubmit={handleAnalyze}>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Enter token address to analyze..."
                className="pl-10 bg-moonshot-dark-bg border-moonshot-dark-bg focus:border-moonshot-purple text-white"
                value={tokenAddress}
                onChange={(e) => setTokenAddress(e.target.value)}
              />
            </div>
          </form>
        )}
        
        {!selectedToken && !tokenAddress && (
          <div className="text-center py-16 text-white">
            Please enter a token address to analyze
          </div>
        )}
        
        {isAnalyzing && (
          <div className="text-center py-16 text-white">
            Analyzing token behavior...
          </div>
        )}

        {mockAnalysis && (
          <div className="space-y-4 text-white">
            <div className="p-4 bg-moonshot-dark-bg rounded-lg">
              <h3 className="font-semibold mb-2">Buyer Behavior</h3>
              <p>{mockAnalysis.buyerBehavior}</p>
            </div>
            <div className="p-4 bg-moonshot-dark-bg rounded-lg">
              <h3 className="font-semibold mb-2">Holder Distribution</h3>
              <p>{mockAnalysis.holderDistribution}</p>
            </div>
            <div className="p-4 bg-moonshot-dark-bg rounded-lg">
              <h3 className="font-semibold mb-2">Creator History</h3>
              <p>{mockAnalysis.creatorHistory}</p>
            </div>
            <div className="p-4 bg-moonshot-dark-bg rounded-lg">
              <h3 className="font-semibold mb-2">Contract Safety</h3>
              <p>{mockAnalysis.contractSafety}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default TokenAnalyzer;
