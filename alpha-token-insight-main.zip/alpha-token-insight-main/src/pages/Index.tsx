
import Header from "@/components/Header";
import MarketOverview from "@/components/MarketOverview";
import TrendingTokens from "@/components/TrendingTokens";
import LiveVolumeSpikes from "@/components/LiveVolumeSpikes";
import TokenAnalyzer from "@/components/TokenAnalyzer";

const Index = () => {
  return (
    <div className="min-h-screen bg-moonshot-dark-bg text-white">
      <Header />
      <main className="container mx-auto px-4 py-6">
        <MarketOverview />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <TrendingTokens />
          </div>
          <div>
            <LiveVolumeSpikes />
          </div>
        </div>
        
        <div className="mt-6">
          <TokenAnalyzer />
        </div>
      </main>
    </div>
  );
};

export default Index;
